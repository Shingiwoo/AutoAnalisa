async def btc_gate_ok() -> bool:
    # stub: selalu OK untuk lokal; dapat dikembangkan
    return True

