'use client'
export default function Loader(){
  return <div className="animate-pulse text-sm opacity-70">Loading…</div>
}

