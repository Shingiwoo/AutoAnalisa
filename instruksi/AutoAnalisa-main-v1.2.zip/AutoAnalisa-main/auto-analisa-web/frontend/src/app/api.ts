export { api } from "../lib/http";
import { api as defaultApi } from "../lib/http";
export default defaultApi;
